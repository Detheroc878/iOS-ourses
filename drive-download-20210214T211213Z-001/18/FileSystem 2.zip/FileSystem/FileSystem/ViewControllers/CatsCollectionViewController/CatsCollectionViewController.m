//
//  CatsCollectionViewController.m
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

#import "CatsCollectionViewController.h"
#import "CatFullScreenViewController.h"
#import "CatCollectionViewCell.h"

#define MB 1024 * 1024

static NSString *const ShowFullScreenCatSegueIdentifier = @"ShowFullScreenCatSegue";

@interface CatsCollectionViewController ()

@property (strong, nonatomic) NSArray *dataSource;
@property (strong, nonatomic) NSCache *imagesCache;

@end

@implementation CatsCollectionViewController

static NSString *const reuseIdentifier = @"CatCollectionViewCell";

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"Images";
    [self prepareDataSource];
    [self setupCache];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:ShowFullScreenCatSegueIdentifier]) {
        NSIndexPath *indexPath = (NSIndexPath *)sender;
        NSString *filePath = self.dataSource[indexPath.item];
        CatCollectionViewCell *cell = (CatCollectionViewCell *)[self.collectionView cellForItemAtIndexPath:indexPath];
        if (!filePath.length || cell == nil) {
            return;
        }
        CGRect imageViewFrame = [self.navigationController.view convertRect:cell.thumbnailImageView.frame fromView:cell];
        
        CatFullScreenViewController *fullScreenVC = (CatFullScreenViewController *)segue.destinationViewController;
        fullScreenVC.presentationRect = imageViewFrame;
        fullScreenVC.imagePath = filePath;
    }
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CatCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    NSString *imagePath = self.dataSource[indexPath.item];
    UIImage *image = [self.imagesCache objectForKey:@(indexPath.item).stringValue];
    if (image == nil) {
        image = [UIImage imageWithContentsOfFile:imagePath];
        if (image != nil) {
            [self.imagesCache setObject:image forKey:@(indexPath.item).stringValue];
        }
    }

    cell.thumbnailImageView.image = image;
    cell.titleLabel.text = [imagePath.lastPathComponent stringByDeletingPathExtension];
    
    return cell;
}

#pragma mark - UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self performSegueWithIdentifier:ShowFullScreenCatSegueIdentifier sender:indexPath];
}

#pragma mark - Data

- (void)prepareDataSource
{
    NSBundle *bundle = [NSBundle mainBundle];
    NSArray *catsPaths = [bundle pathsForResourcesOfType:@"jpg" inDirectory:@"Cats"];
    self.dataSource = catsPaths;
}

#pragma mark - Cache

- (void)setupCache
{
    self.imagesCache = [NSCache new];
    self.imagesCache.totalCostLimit = 20 * MB;
}

@end
