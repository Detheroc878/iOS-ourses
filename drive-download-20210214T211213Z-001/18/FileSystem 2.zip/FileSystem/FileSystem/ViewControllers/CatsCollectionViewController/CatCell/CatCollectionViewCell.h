//
//  CatCollectionViewCell.h
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

@interface CatCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumbnailImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
