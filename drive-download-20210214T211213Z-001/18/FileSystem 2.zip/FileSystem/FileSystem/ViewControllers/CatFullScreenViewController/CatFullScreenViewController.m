//
//  CatFullScreenViewController.m
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

#import "CatFullScreenViewController.h"

static CGFloat const PresentationAnimationDuration = 0.3f;
static CGFloat const DefaultScrollViewZoomScale = 1.01f;

@interface CatFullScreenViewController () <UIScrollViewDelegate>

@property (strong, nonatomic) UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIView *backgroundView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (assign, nonatomic) BOOL isShown;

@end

@implementation CatFullScreenViewController

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    _isShown = NO;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.scrollView.minimumZoomScale = DefaultScrollViewZoomScale;
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    if (!_isShown) {
        _isShown = YES;
        [self animateAppearance];
    }
}

- (UIImageView *)imageView
{
    if (_imageView == nil) {
        UIImage *image = [UIImage imageWithContentsOfFile:self.imagePath];
        _imageView = [[UIImageView alloc] initWithImage:image];
        _imageView.contentMode = UIViewContentModeScaleAspectFill;
        _imageView.clipsToBounds = YES;
        _imageView.frame = self.presentationRect;
        [self.view addSubview:_imageView];
    }
    return _imageView;
}

#pragma mark - Animations

- (void)animateAppearance
{
    CGRect fromRect = self.presentationRect;
    CGRect toRect = [self fullScreenImageViewFrame];
    CGPoint fromPoint = [self positonForFrame:fromRect];
    CGPoint toPoint = [self positonForFrame:toRect];
    fromRect = self.imageView.bounds;
    
    // we will animate bounds and position
    fromRect.origin = CGPointZero;
    toRect.origin = CGPointZero;
    CAAnimationGroup *animation = [self animationGroupFromPosition:fromPoint toPosition:toPoint andFromBounds:fromRect toBounds:toRect];
    [self.imageView.layer addAnimation:animation forKey:@"Appearance"];
    
    self.imageView.layer.bounds = toRect;
    self.imageView.layer.position = toPoint;
    
    [UIView animateWithDuration:PresentationAnimationDuration animations:^{
        self.backgroundView.alpha = 1;
    }];
}

- (void)animateDismiss
{
    CGRect frame = self.imageView.frame;
    frame.origin = CGPointMake(self.scrollView.frame.origin.x - self.scrollView.contentOffset.x, self.scrollView.frame.origin.y - self.scrollView.contentOffset.y);
    [self.imageView removeFromSuperview];
    self.imageView.frame = frame;
    [self.view addSubview:self.imageView];
    
    CGRect fromRect = frame;
    CGRect toRect = self.presentationRect;
    CGPoint fromPoint = [self positonForFrame:fromRect];
    CGPoint toPoint = [self positonForFrame:toRect];
    fromRect = self.imageView.bounds;
    
    // we will animate bounds and position
    fromRect.origin = CGPointZero;
    toRect.origin = CGPointZero;
    CAAnimationGroup *animation = [self animationGroupFromPosition:fromPoint toPosition:toPoint andFromBounds:fromRect toBounds:toRect];
    [self.imageView.layer addAnimation:animation forKey:@"Dismiss"];
    
    self.imageView.layer.bounds = toRect;
    self.imageView.layer.position = toPoint;
    
    [UIView animateWithDuration:PresentationAnimationDuration animations:^{
        self.backgroundView.alpha = 0;
    }];
}

- (CAAnimationGroup *)animationGroupFromPosition:(CGPoint)fromPosition toPosition:(CGPoint)toPosition andFromBounds:(CGRect)fromBounds toBounds:(CGRect)toBounds
{
    CABasicAnimation *positionAnim = [CABasicAnimation animationWithKeyPath:@"position"];
    positionAnim.fromValue = [NSValue valueWithCGPoint:fromPosition];
    positionAnim.toValue = [NSValue valueWithCGPoint:toPosition];

    CABasicAnimation *boundsAnim = [CABasicAnimation animationWithKeyPath:@"bounds"];
    boundsAnim.fromValue = [NSValue valueWithCGRect:fromBounds];
    boundsAnim.toValue = [NSValue valueWithCGRect:toBounds];
    
    CAAnimationGroup *group = [CAAnimationGroup animation];
    group.duration = PresentationAnimationDuration;
    group.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    group.animations = @[positionAnim, boundsAnim];
    group.removedOnCompletion = NO;
    group.delegate = self;
    
    return group;
}

#pragma mark - AnimationDelegate

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    if (anim == [self.imageView.layer animationForKey:@"Appearance"]) {
        [self.imageView.layer removeAllAnimations];
        [self.imageView removeFromSuperview];
        [self.scrollView addSubview:self.imageView];
        self.scrollView.zoomScale = DefaultScrollViewZoomScale;
    } if (anim == [self.imageView.layer animationForKey:@"Dismiss"]) {
        [self.imageView.layer removeAllAnimations];
        [self dismissViewControllerAnimated:NO completion:nil];
    }
}

#pragma mark - Utils

- (CGRect)fullScreenImageViewFrame
{
    CGRect frame = CGRectZero;
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGSize imageSize = self.imageView.image.size;
    CGFloat imageAspect = imageSize.height / imageSize.width;
    CGFloat screenAspect = screenSize.height / screenSize.width;
    
    if (imageAspect > screenAspect) {
        // use full screen height
        frame.size.height = screenSize.height;
        frame.size.width = screenSize.height / imageAspect;
        frame.origin.x = (screenSize.width - frame.size.width) / 2;
    } else {
        // use full screen width
        frame.size.width = screenSize.width;
        frame.size.height = screenSize.height / imageAspect;
        frame.origin.y = (screenSize.height - frame.size.height) / 2;
    }
    return frame;
}

- (CGPoint)positonForFrame:(CGRect)frame
{
    CGPoint position = CGPointZero;
    position.x = CGRectGetMaxX(frame) - CGRectGetWidth(frame) * 0.5;
    position.y = CGRectGetMaxY(frame) - CGRectGetHeight(frame) * 0.5;
    return position;
}

#pragma mark - UIScrollViewDelegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    CGFloat offsetX = MAX((scrollView.bounds.size.width - scrollView.contentSize.width) / 2, 0.0);
    CGFloat offsetY = MAX((scrollView.bounds.size.height - scrollView.contentSize.height) / 2, 0.0);
    
    self.imageView.center = CGPointMake(scrollView.contentSize.width / 2 + offsetX, scrollView.contentSize.height / 2 + offsetY);
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.zoomScale == DefaultScrollViewZoomScale && self.scrollView.subviews.count) {
        CGFloat offset = MAX(ABS(scrollView.contentOffset.x), ABS(scrollView.contentOffset.y));
        CGFloat newAlpha = ((300 - offset) / 300);
        self.backgroundView.alpha = newAlpha > 0.5 ? newAlpha : 0.5;
        if (offset >= 70 && !self.scrollView.isDragging) {
            [self animateDismiss];
        }
    }
}

@end
