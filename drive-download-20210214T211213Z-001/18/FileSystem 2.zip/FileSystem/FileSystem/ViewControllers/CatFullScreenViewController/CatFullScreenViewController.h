//
//  CatFullScreenViewController.h
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

@interface CatFullScreenViewController : UIViewController

@property (assign ,nonatomic) CGRect presentationRect;
@property (copy, nonatomic) NSString *imagePath;

@end
