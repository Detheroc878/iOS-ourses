//
//  ViewController.m
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

#import "MainTableViewController.h"
#import "FilesTableViewController.h"

static NSString *const PresentWelcomeScreenSegueIdentifier = @"PresentWelcomeScreenSegueIdentifier";
static NSString *const DocumentsSegueIdentifier = @"Documents";
static NSString *const TmpSegueIdentifier = @"Temp";
static NSString *const ApplicationSupportSegueIdentifier = @"Support";

@interface MainTableViewController ()

@end

@implementation MainTableViewController

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.clearsSelectionOnViewWillAppear = YES;
    [self showRateApp];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults boolForKey:WelcomeIsShownUserDefaultsKey]) {
        [self performSegueWithIdentifier:PresentWelcomeScreenSegueIdentifier sender:nil];
    }
    [defaults setBool:YES forKey:WelcomeIsShownUserDefaultsKey];
}

#pragma mark - Exit

- (IBAction)closeWeclomeScreen:(UIStoryboardSegue *)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - RateApp

- (void)showRateApp
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults boolForKey:RateAppRestrictedUserDefaultsKey]) {
        return;
    }
    
    NSInteger launchesCount = [defaults integerForKey:RateAppCounterUserDefaultsKey];
    launchesCount++;
    if (launchesCount == 3) {
        launchesCount = 0;
        [self openRateAppAlert];
    }
    [defaults setInteger:launchesCount forKey:RateAppCounterUserDefaultsKey];
    [defaults synchronize];
}

- (void)openRateAppAlert
{
    __block void (^restrictRateAppBlock)() = ^{
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:RateAppRestrictedUserDefaultsKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
    };
    
    NSString *message = @"If You like this app, please give us 5 stars on App Store";
    UIAlertController *rateAppAlert = [UIAlertController alertControllerWithTitle:@"Rate this app" message:message preferredStyle:UIAlertControllerStyleAlert];
    [rateAppAlert addAction:[UIAlertAction actionWithTitle:@"Go to App Store" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        restrictRateAppBlock();
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://"]];
    }]];
    [rateAppAlert addAction:[UIAlertAction actionWithTitle:@"Remind me later" style:UIAlertActionStyleDefault handler:nil]];
    [rateAppAlert addAction:[UIAlertAction actionWithTitle:@"I don't like it" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        restrictRateAppBlock();
    }]];
    [self presentViewController:rateAppAlert animated:NO completion:nil];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    FilesTableViewController *filesVC = segue.destinationViewController;
    if (![filesVC isKindOfClass:[FilesTableViewController class]]) {
        return;
    }
    if ([segue.identifier isEqualToString:DocumentsSegueIdentifier]) {
        filesVC.rootFolderPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    } else if ([segue.identifier isEqualToString:TmpSegueIdentifier]) {
        filesVC.rootFolderPath = NSTemporaryDirectory();
    } else {
        NSURL *dirURL = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
        filesVC.rootFolderPath = dirURL.path;
    }
}

@end
