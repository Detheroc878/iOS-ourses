//
//  FilesTableViewController.m
//  FileSystem
//
//  Created by  on 4/19/16.
//  Copyright © 2016 . All rights reserved.
//

#import "FilesTableViewController.h"

@interface FilesTableViewController ()

@property (strong, nonatomic) NSArray *dataSource;

@end

@implementation FilesTableViewController

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.clearsSelectionOnViewWillAppear = YES;
    self.navigationItem.title = self.rootFolderPath.lastPathComponent;
    [self loadFolderContents];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FileCell" forIndexPath:indexPath];
    
    NSString *file = self.dataSource[indexPath.row];
    cell.textLabel.text = file.lastPathComponent;
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *file = self.dataSource[indexPath.row];
    BOOL isDirectory = [self isFileDirectory:[self.rootFolderPath stringByAppendingPathComponent:file]];
    if (isDirectory) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *file = self.dataSource[indexPath.row];
    BOOL isDirectory = [self isFileDirectory:[self.rootFolderPath stringByAppendingPathComponent:file]];
    if (isDirectory) {
        FilesTableViewController *filesVC = [self.storyboard instantiateViewControllerWithIdentifier:NSStringFromClass(self.class)];
        filesVC.rootFolderPath = [self.rootFolderPath stringByAppendingPathComponent:file];
        [self.navigationController pushViewController:filesVC animated:YES];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *file = self.dataSource[indexPath.row];
    NSMutableArray *dataSource = self.dataSource.mutableCopy;
    [dataSource removeObject:file];
    
    [tableView beginUpdates];
    self.dataSource = dataSource;
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [tableView endUpdates];
    
    NSError *error;
    [[NSFileManager defaultManager] removeItemAtPath:[self.rootFolderPath stringByAppendingPathComponent:file] error:&error];
    if (error != nil) {
        NSLog(@"Delete file error: %@", error);
    }
}

#pragma mark - Actions

- (IBAction)addNewItemAction:(id)sender
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Create new" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:@"Folder" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self getFileNameWithCompletion:^(NSString *fileName) {
            if (fileName.length) {
                [self createDirectoryWithName:fileName];
            }
        }];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"File" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self getFileNameWithCompletion:^(NSString *fileName) {
            if (fileName.length) {
                [self createFileWithName:fileName];
            }
        }];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - File Creation

- (void)getFileNameWithCompletion:(void (^)(NSString *fileName))completion
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Enter new name" message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:nil];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (completion) {
            completion(nil);
        }
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Create" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *textField = alert.textFields.firstObject;
        if (textField.text.length == 0) {
            [self showErrorWithMessage:@"Please enter file name" onDismiss:completion];
        } else if (completion) {
            NSString *invalidCharacters = [self invalidCharactersInFileName:textField.text];
            if (invalidCharacters.length) {
                completion(nil);
                NSString *errorMessage = [NSString stringWithFormat:@"File name can not contain \"%@\". Please enter valid name", invalidCharacters];
                [self showErrorWithMessage:errorMessage onDismiss:completion];
            } else {
                completion(textField.text);
            }
        }
    }]];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self presentViewController:alert animated:YES completion:nil];
    });
}

- (void)showErrorWithMessage:(NSString *)message onDismiss:(void (^)(NSString *))completion
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (completion) {
            [self getFileNameWithCompletion:completion];
        }
    }]];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self presentViewController:alert animated:YES completion:nil];
    });
}

- (void)createDirectoryWithName:(NSString *)folderName
{
    NSString *newFolderPath = [self.rootFolderPath stringByAppendingPathComponent:folderName];
    if ([[NSFileManager defaultManager] fileExistsAtPath:newFolderPath]) {
        [self showErrorWithMessage:@"Folder already exists" onDismiss:nil];
        return;
    }
    
    NSError *error;
    [[NSFileManager defaultManager] createDirectoryAtPath:newFolderPath withIntermediateDirectories:NO attributes:nil error:&error];
    if (error != nil) {
        NSLog(@"Create directory error: %@", error);
    } else {
        [self loadFolderContents];
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

- (void)createFileWithName:(NSString *)fileName
{
    NSString *newFilePath = [[self.rootFolderPath stringByAppendingPathComponent:fileName] stringByAppendingPathExtension:@"txt"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:newFilePath]) {
        [self showErrorWithMessage:@"File already exists" onDismiss:nil];
        return;
    }
    
    NSError *error;
    [[NSFileManager defaultManager] createFileAtPath:newFilePath contents:[@"Hello world" dataUsingEncoding:NSUTF8StringEncoding] attributes:nil];
    if (error != nil) {
        NSLog(@"Create file error: %@", error);
    } else {
        [self loadFolderContents];
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark - Data

- (void)loadFolderContents
{
    NSError *error;
    if (![self isFileDirectory:self.rootFolderPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:self.rootFolderPath withIntermediateDirectories:NO attributes:nil error:&error];
        if (error != nil) {
            NSLog(@"Create directory error: %@", error);
            error = nil;
        }
    }
    
    NSArray *contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.rootFolderPath error:&error];
    if (error != nil) {
        NSLog(@"Get directory contents error: %@", error);
    }
    self.dataSource = contents;
}

#pragma mark - Private

- (BOOL)isFileDirectory:(NSString *)filePath
{
    BOOL isDirectory;
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDirectory];
    return fileExists && isDirectory;
}

- (NSString *)invalidCharactersInFileName:(NSString *)aFileName
{
    NSMutableString *returnString = [NSMutableString string];
    NSCharacterSet *invalidCharactersSet = [NSCharacterSet characterSetWithCharactersInString:@"\\/:*?\"<>|%"];
    NSUInteger length = aFileName.length;
    
    unichar buffer[length];
    [aFileName getCharacters:buffer range:NSMakeRange(0, length)];
    
    for (int i = 0; i < length; i++) {
        unichar c = buffer[i];
        if ([invalidCharactersSet characterIsMember:c] && ![returnString containsString:[NSString stringWithFormat:@"%c", c]]) {
            [returnString appendFormat:@"%c", c];
        }
    }
    return returnString;
}

@end
