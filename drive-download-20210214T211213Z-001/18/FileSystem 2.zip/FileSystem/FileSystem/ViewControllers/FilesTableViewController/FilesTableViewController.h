//
//  FilesTableViewController.h
//  FileSystem
//
//  Created by  on 4/19/16.
//  Copyright © 2016 . All rights reserved.
//

@interface FilesTableViewController : UITableViewController

@property (strong, nonatomic) NSString *rootFolderPath;

@end
