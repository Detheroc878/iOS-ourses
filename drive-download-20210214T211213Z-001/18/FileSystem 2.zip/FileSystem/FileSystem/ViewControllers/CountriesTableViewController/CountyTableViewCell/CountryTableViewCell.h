//
//  CountryTableViewCell.h
//  FileSystem
//
//  Created by  on 4/18/16.
//  Copyright © 2016 . All rights reserved.
//

@interface CountryTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;

@end
