//
//  CountriesTableViewController.m
//  FileSystem
//
//  Created by  on 4/18/16.
//  Copyright © 2016 . All rights reserved.
//

#import "CountriesTableViewController.h"
#import "CountryTableViewCell.h"
#import "CountryModel.h"

@interface CountriesTableViewController ()

@property (strong, nonatomic) NSArray<CountryModel *> *dataSource;

@end

@implementation CountriesTableViewController

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self prepareDataSource];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CountryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CountryTableViewCell" forIndexPath:indexPath];
    CountryModel *country = self.dataSource[indexPath.section];
    
    NSString *description = indexPath.row == 0 ? @"Name" : @"Nationality";
    NSString *detail = indexPath.row == 0 ? country.name : country.nationality;
    if (indexPath.row == 1) {
        description = @"Capital";
        detail = country.capital;
    }
    cell.descriptionLabel.text = description;
    cell.detailLabel.text = detail;
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    CountryModel *country = self.dataSource[section];
    return country.name;
}

#pragma mark - DataSource

- (void)prepareDataSource
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"Countries" ofType:@"plist"];
    if (plistPath.length) {
        NSArray *countiesInfo = [NSArray arrayWithContentsOfFile:plistPath];
        self.dataSource = [CountryModel countiesWithDictionariesArray:countiesInfo];
    }
}

@end
