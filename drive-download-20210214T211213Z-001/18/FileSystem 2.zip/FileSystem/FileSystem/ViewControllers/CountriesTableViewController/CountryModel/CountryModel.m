//
//  CountryModel.m
//  FileSystem
//
//  Created by  on 4/18/16.
//  Copyright © 2016 . All rights reserved.
//

#import "CountryModel.h"

@implementation CountryModel

- (instancetype)initWithDictionary:(NSDictionary *)aDictionary
{
    self = [super init];
    if (self && aDictionary) {
        _name = aDictionary[@"Name"];
        _capital = aDictionary[@"Capital"];
        _nationality = aDictionary[@"Nationality"];
    }
    return self;
}

+ (NSArray<CountryModel *> *)countiesWithDictionariesArray:(NSArray *)dictArray
{
    NSMutableArray *countiesArray = [NSMutableArray array];
    for (NSDictionary *dict in dictArray) {
        if ([dict isKindOfClass:[NSDictionary class]]) {
            [countiesArray addObject:[[CountryModel alloc] initWithDictionary:dict]];
        }
    }
    return countiesArray;
}

#warning Unused test code
#pragma mark - NSCoder

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [self initWithDictionary:nil];
    if (self) {
        _name = [aDecoder decodeObjectForKey:@"Name"];
        _capital = [aDecoder decodeObjectForKey:@"Capital"];
        _nationality = [aDecoder decodeObjectForKey:@"Nationality"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_name forKey:@"Name"];
    [aCoder encodeObject:_capital forKey:@"Capital"];
    [aCoder encodeObject:_nationality forKey:@"Nationality"];
}

- (void)save
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self];
    if (data != nil) {
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"someKey"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (instancetype)load
{
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"someKey"];
    if (data != nil) {
        CountryModel *country = [NSKeyedUnarchiver unarchiveObjectWithData:data];
        return country;
    }
    return nil;
}

@end
