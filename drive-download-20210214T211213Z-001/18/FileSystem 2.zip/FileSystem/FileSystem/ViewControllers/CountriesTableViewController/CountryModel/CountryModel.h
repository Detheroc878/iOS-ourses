//
//  CountryModel.h
//  FileSystem
//
//  Created by  on 4/18/16.
//  Copyright © 2016 . All rights reserved.
//

@interface CountryModel : NSObject <NSCoding>

@property (strong, nonatomic, readonly) NSString *name;
@property (strong, nonatomic, readonly) NSString *capital;
@property (strong, nonatomic, readonly) NSString *nationality;

- (instancetype)initWithDictionary:(NSDictionary *)aDictionary;
+ (NSArray<CountryModel *> *)countiesWithDictionariesArray:(NSArray *)dictArray;

- (instancetype)load;
- (void)save;

@end
