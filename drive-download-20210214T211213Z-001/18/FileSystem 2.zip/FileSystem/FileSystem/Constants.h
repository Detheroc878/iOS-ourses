//
//  Constants.h
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

#ifndef Constants_h
#define Constants_h

static NSString *const RateAppCounterUserDefaultsKey = @"RateAppCounterUserDefaultsKey";
static NSString *const RateAppRestrictedUserDefaultsKey = @"RateAppRestrictedUserDefaultsKey";

static NSString *const WelcomeIsShownUserDefaultsKey = @"WelcomeIsShownUserDefaultsKey";

#endif /* Constants_h */
