//
//  AppDelegate.m
//  FileSystem
//
//  Created by  on 4/14/16.
//  Copyright © 2016 . All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[NSUserDefaults standardUserDefaults] setValue:@"Hello" forKey:@"Sample"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    // Override point for customization after application launch
    return YES;
}

@end
