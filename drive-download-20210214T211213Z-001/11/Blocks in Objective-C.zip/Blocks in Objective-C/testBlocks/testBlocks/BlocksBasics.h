//
//  BlocksBasics.h
//  testBlocks
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BlocksBasics : NSObject

@property (copy, nonatomic) void (^DidDeallocClass)();
@property (copy, nonatomic) void (^completion)(BOOL result);

- (void)testPointer;

- (NSInteger )countAllValue;
- (NSInteger)multiplyValueBy2:(NSInteger)inputValue;
- (void)localVariable;

- (void)testBlock:(void(^)())completion;
- (void (^)(BOOL))someMethod:(void (^)(BOOL value))handler;

- (void)someMethodWithBlockPropertyUsage;

- (void)operationBlock;

- (void)blockTypes;

@end
