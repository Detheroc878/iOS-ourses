//
//  BlockStack.h
//  testBlocks
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BlockStack : NSObject

void showStackBlock();

@end
