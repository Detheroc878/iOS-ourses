//
//  main.m
//  testBlocks
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BlocksBasics.h"
#import "RetainCycleInBlock.h"
#import "BlockStack.h"

//MARK: typeDef for block

typedef void (^TypedDefForBlock)(NSInteger, NSString *);
typedef int (^TypedDefForBlockReturnValue)(NSInteger argOne, NSString *argTwo);
typedef NSString* (^TypedDefForBlockShort)(NSInteger, NSString *);

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//
        BlocksBasics *basics = [[BlocksBasics alloc] init];
//
//        //MARK: Block asParameterto Method
//        [basics testBlock:^{
//            NSLog(@"testBlock completed");
//        }];
//        
//        void (^something)(BOOL val) = ^(BOOL val){
//            
//        };
//        basics.completion = [basics someMethod:something];
//
//        //MARK: testBlock As property
//        basics.DidDeallocClass = ^(){ //() optional i this case
//            NSLog(@"Dealloc");
//        };
//        basics.completion = ^(BOOL flag) {
//            if (flag) {
//                NSLog(@"Hello");
//            } else {
//                NSLog(@"Goodbay");
//            }
//        };
//        [basics someMethodWithBlockPropertyUsage];
//
//        //MARK: LocalVariable
//        [basics countAllValue];
//        [basics multiplyValueBy2:10];
//        [basics localVariable];
//
//        //MARK: Block types
//        [basics blockTypes];
//        showStackBlock();
//
//        //MARK: Pointer to function
//        [basics testPointer];
        
//        //MARK: NotificationBlock
        [basics operationBlock];
//
//        //MARK: Retain cycle
//        RetainCycleInBlock *retainCycleObj = [[RetainCycleInBlock alloc] init];
//        [retainCycleObj callblock];

    }
    return 0;
}
