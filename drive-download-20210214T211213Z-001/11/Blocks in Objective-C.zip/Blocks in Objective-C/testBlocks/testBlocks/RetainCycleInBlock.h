//
//  RatainCycleInBlock.h
//  testBlock
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^MyBlock)(void);

@interface RetainCycleInBlock : NSObject

@property (copy, nonatomic) MyBlock block;

- (void)callblock;


@end
