//
//  BlockStack.m
//  testBlocks
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import "BlockStack.h"

@implementation BlockStack

void exampleB_addBlockToArray(NSMutableArray *array) {
    char b = 'B';
    [array addObject:^{
        printf("%cn", b);
    }];
    NSLog(@"Stack - %@", array[0]);
}

void showStackBlock() {
    NSMutableArray *array = [NSMutableArray array];
    exampleB_addBlockToArray(array);
}

@end
