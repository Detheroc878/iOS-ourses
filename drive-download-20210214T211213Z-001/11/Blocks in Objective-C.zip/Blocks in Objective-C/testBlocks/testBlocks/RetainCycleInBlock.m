//
//  RatainCycleInBlock.m
//  testBlock
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import "RetainCycleInBlock.h"

@implementation RetainCycleInBlock

- (id)init
{
    if ((self = [super init])) {
        
        NSLog(@"init");
//        __weak typeof(self) weakSelf = self; //uncomment to fix
        self.block = ^{
//            __strong __typeof(weakSelf) strongSelf = weakSelf; //uncomment to fix
            NSLog(@"object is %@", self); // self retain cycle
        };
    }
    return self;
}

- (void)dealloc
{
    self.block = nil;
    NSLog (@"end"); // never called.
}

- (void)callblock
{
    self.block();
}

@end
