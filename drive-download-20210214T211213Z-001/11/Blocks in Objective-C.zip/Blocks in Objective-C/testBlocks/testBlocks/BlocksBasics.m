//
//  BlocksBasics.m
//  testBlocks
//
//  Created by Kirill Gorbushko on 12.02.16.
//  Copyright © 2016 - present . All rights reserved.
//

#import "BlocksBasics.h"

typedef void(^MyAwesomeBlock)(NSArray *array);

@interface BlocksBasics ()

//MARK: testBlock As property

@property (copy, nonatomic) MyAwesomeBlock awesomeBlock;

@property (assign, nonatomic) void (*someFunction)(int);

@end

@implementation BlocksBasics

//MARK: Pointer to function
void logger(int num) {
    NSLog(@"Number %d", num);
}

- (void)testPointer
{
    self.someFunction = logger;
    self.someFunction(522);
}

//MARK: LocalVariable

- (NSInteger)countAllValue
{
    int(^counter)(NSArray *input) = ^(NSArray *arr) {
        int counter = 0;
        for (int i = 0; i < arr.count; i++) {
            counter += [arr[i] integerValue];
        }
        return counter;
    };
    
    int b = counter(@[@3, @5]);
    int c = counter(@[@4, @5]);
    
    NSLog(@"Result of counting - %i", (b+c));
    
    return b + c;
}

- (NSInteger)multiplyValueBy2:(NSInteger)inputValue
{
    __block int result = (int)inputValue;
    void(^multi)() = ^{
        result *= 2;
    };
    
    for (int i = 0; i < 15; i++) {
        multi();
    }
    return result;
}

- (void)localVariable
{
    int (^describeNumber)(int x) = ^(int x){
        NSLog(@"number - %i", x);
        return x * 2;
    };
    
    int b = describeNumber(3);
    
    int c = b + 2;
    NSLog(@"number - %i", c);
}

//MARK: Block asParameterto Method

- (void)testBlock:(void(^)())completion
{
    int counter = 0;
    for (int i = 0; i < 10000; i++) {
        counter++;
        if (!(counter % 50)) {
            completion();
        }
    }
}

- (void (^)(BOOL value))someMethod:(void (^)(BOOL value))handler
{
    return handler;
}

//MARK: as property

- (void)someMethodWithBlockPropertyUsage
{
    if (self.completion) {
        self.completion(NO);
        self.completion = nil;
    }
}

//MARK: BlockTypes

void (^StringDisplayBlock)(NSString *inputString) = ^(NSString *inputString) {
    NSLog(@"%@", inputString);
};

- (void)blockTypes
{
    void(^myBlock)(void) = ^{

    };
    NSLog(@"%@", myBlock);
    myBlock();
    
    void (^something)(BOOL val) = ^(BOOL val){
        
    };
    self.completion = something;
    NSLog(@"%@", self.completion);
}

- (void)operationBlock
{
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"do something");
    }];
    
    NSBlockOperation *operation1 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"do something1");
    }];
    
    NSOperationQueue *myQueue = [NSOperationQueue new];
    [myQueue addOperations:@[operation, operation1] waitUntilFinished:YES];
}

//MARK: Dealloc

- (void)dealloc
{
    if (self.DidDeallocClass) {
        self.DidDeallocClass();
        self.DidDeallocClass = nil;
    }
    NSLog(@"Dealloc main");
}

@end
