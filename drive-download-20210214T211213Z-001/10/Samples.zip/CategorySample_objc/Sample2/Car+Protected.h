
#import <Foundation/Foundation.h>
#import "Car.h"

@interface Car (Protected)

- (void)prepareToDrive;

@end
