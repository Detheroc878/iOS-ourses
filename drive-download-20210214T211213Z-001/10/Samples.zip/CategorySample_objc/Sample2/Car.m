
#import "Car.h"
#import "Car+Protected.h"

//// The class extension
@interface Car ()

//@property (readwrite) double odometer;
//
//- (BOOL)engineIsWorking;
//
//@end

@implementation Car {
    int _something;
}

@synthesize model = _model;
//
//- (BOOL)engineIsWorking {
//    // In the real world, this would probably return a useful value
//    return YES;
//}

- (void)startEngine {
//    if ([self engineIsWorking]) {
        NSLog(@"Starting the %@'s engine", _model);
//    }

    _something = 1232;

    self.odometer = 12;
}

- (void)drive {
    [self prepareToDrive];
    NSLog(@"The %@ is now driving", _model);
}

- (void)turnLeft {
    NSLog(@"The %@ is turning left", _model);
}

- (void)turnRight {
    NSLog(@"The %@ is turning right", _model);
}

@end
