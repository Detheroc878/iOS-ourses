//
//  NSObject+Test.h
//  Sample2
//
//  Created by Kirill Gorbushko on 10.05.18.
//

#import <Foundation/Foundation.h>

@interface NSObject (Test)

- (void)doUsefullStuff;

@end
