//
//  NSObject+Test.m
//  Sample2
//
//  Created by Kirill Gorbushko on 10.05.18.
//

#import "NSObject+Test.h"

@implementation NSObject (Test)

- (void) doUsefullStuff
{
    NSLog(@"great!");
}

@end
