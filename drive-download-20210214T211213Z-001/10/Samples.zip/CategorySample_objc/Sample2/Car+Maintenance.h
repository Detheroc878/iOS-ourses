
#import "Car.h"

@interface Car (Maintenance)

- (instancetype)init:(Car * )carObject;

- (BOOL)needsOilChange;
- (void)changeOil;
- (void)rotateTires;
- (void)jumpBatteryUsingCar:(Car *)anotherCar;

@end
