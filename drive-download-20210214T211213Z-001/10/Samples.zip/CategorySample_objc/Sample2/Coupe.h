

#import "Car.h"

@interface Coupe : Car

@end
