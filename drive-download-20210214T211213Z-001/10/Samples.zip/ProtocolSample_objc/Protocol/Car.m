
#import "Car.h"

@implementation Car

- (void)signalStop
{
    NSLog(@"Stop signal");
}

- (void)signalLeftTurn
{
    NSLog(@"Left turn signal");
}

- (void)signalRightTurn
{
    NSLog(@"Right turn signal");
}

@end
