
#import <Foundation/Foundation.h>
#import "FixCrash.h"

@protocol StreetLegal <NSObject, FixCrash>

@required
- (void)signalStop;
- (void)signalLeftTurn;
- (void)signalRightTurn;

@end
