
#import <Foundation/Foundation.h>

#import "StreetLegal.h"

@interface Bicycle : NSObject <StreetLegal>

@property (assign, nonatomic, readonly) NSInteger countWheel;

- (void)startPedaling;
- (void)removeFrontWheel;
- (void)crashWheel;

@end
