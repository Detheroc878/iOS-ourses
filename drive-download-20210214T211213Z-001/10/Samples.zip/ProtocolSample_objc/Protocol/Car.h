
#import <Foundation/Foundation.h>

#import "StreetLegal.h"

@interface Car : NSObject <StreetLegal>

@end
