
#import <Foundation/Foundation.h>

@protocol FixCrash <NSObject>

@optional
- (void)fix;

@end
