
#import "Bicycle.h"

@interface Bicycle ()

@property (assign, nonatomic) NSInteger countWheel;

@end

@implementation Bicycle

#pragma mark - Lifecycle

- (instancetype)init
{
    self = [super init];
    if (self) {
        _countWheel = 1;
    }
    return self;
}

#pragma mark - Custom Accessors

- (void)setCountWheel:(NSInteger)countWheel
{
    _countWheel = countWheel;
    if (countWheel < 0) {
        _countWheel = 0;
    }
    NSLog(@"Count Wheel - %li", (long)self.countWheel);
}

#pragma mark - Public

- (void)startPedaling
{
    NSLog(@"Here we go!");
}

- (void)removeFrontWheel
{
    NSLog(@"Front wheel is off. Should probably replace that before pedaling...!");
}



#pragma mark - StreetLegal Delegate

- (void)crashWheel
{
    _countWheel--;
    NSLog(@"Ohh, no I lose one wheel");
}

- (void)signalStop
{
    NSLog(@"Bending left arm downwards");
}

- (void)signalLeftTurn
{
    NSLog(@"Extending left arm outwards");
}

- (void)signalRightTurn
{    
    NSLog(@"Bending left arm upwards");
}

#pragma mark - FixCrash Delegate

- (void)fix
{
    _countWheel = 2;
    NSLog(@"Yes, wheel is fixed");
    NSLog(@"Count Wheel - %li", (long)self.countWheel);
}

@end
