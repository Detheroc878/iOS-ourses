
#import "Boat.h"

@implementation Boat

@end
