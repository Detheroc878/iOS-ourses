
#import <Foundation/Foundation.h>

@interface Boat : NSObject

@end
