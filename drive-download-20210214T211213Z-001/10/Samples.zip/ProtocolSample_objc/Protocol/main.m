#import <Foundation/Foundation.h>

#import "Bicycle.h"
#import "Car.h"
#import "Boat.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        //1
        Bicycle *bike = [[Bicycle alloc] init];
        [bike startPedaling];
        [bike signalLeftTurn];
        [bike signalStop];
        [bike crashWheel];
        [bike fix];

        NSObject *something = bike;
        id somethingsdfa = something;

        //2
        id <StreetLegal> mysteryVehicle = [[Car alloc] init];
        [mysteryVehicle signalLeftTurn];

        mysteryVehicle = [[Bicycle alloc] init];
        [mysteryVehicle signalLeftTurn];
        
        //2.1
        mysteryVehicle = [[Boat alloc] init];
//        [mysteryVehicle signalLeftTurn];
        if ([mysteryVehicle conformsToProtocol:@protocol(StreetLegal)]) {
            [mysteryVehicle signalLeftTurn];
        }
    }
    return 0;
}

