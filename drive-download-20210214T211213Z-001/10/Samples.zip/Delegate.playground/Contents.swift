//: Playground - noun: a place where people can play

import UIKit

protocol OwnerDelegate: class {
    func printText(text: String)
}

class Owner {

    weak var delegate:OwnerDelegate?

    init(delegate:OwnerDelegate? = nil) {
        self.delegate = delegate
    }

    var text : String? {
        didSet {
            delegate?.printText(text: text ?? "nothing to print")
        }
    }
}

class Printer: OwnerDelegate {
    func printText(text: String) {
        print(text)
    }
}

let printer: OwnerDelegate = Printer()
var owner = Owner()
owner.delegate = printer
owner.text = "Hello"
owner.text = "World!"
owner.text = "Some printing stuff"


protocol Printable {
    var character: Character { get set }
}

extension Printable {
    func printDescription() {
        print(character)
    }
}

struct SomePrintabe: Printable {
    var character: Character = "a"
}

let object = SomePrintabe()
object.printDescription()


