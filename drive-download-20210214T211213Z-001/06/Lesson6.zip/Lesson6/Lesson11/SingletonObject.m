//
//  SingletonObject.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "SingletonObject.h"

@implementation SingletonObject

+ (instancetype)sharedInstance
{
    static id sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // this code will be called only once in program
        sharedInstance = [[self alloc] init]; // will call custom init below
    });
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        // optional
        // custom init
    }
    return self;
}

- (void)setupDefaults
{
    // optional
    // setup default state
    // call this method to reset singleton state to default if it is needed
}

- (void)configureWithName:(NSString *)aName
{
    // optional
    // used to change state for next task or iteration
    // some values should not change, another way call setupDefaults
}

@end
