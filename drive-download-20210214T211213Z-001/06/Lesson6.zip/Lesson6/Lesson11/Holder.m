//
//  Holder.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "Holder.h"

@implementation Holder

@end
