//
//  ClassB.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "ClassB.h"

@implementation ClassB

- (void)createValue
{
    NSObject *value = [NSObject new];
    // value is local object in this method
    // if nothing keeps it, it will be deleted after method will end
    // like in this case
    _value = value;
}

- (void)printValue
{
    NSLog(@"%@", self.value);
}

@end
