//
//  ClassB.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ClassA;

@interface ClassB : NSObject

@property (strong, nonatomic) ClassA *obj; // will increase retain count of obj. obj could be deleted only when this instance will dealloc or if set this property to nil (in case this is the only strong reference to obj)

@property (weak, nonatomic, readonly) NSObject *value;

- (void)createValue;
- (void)printValue;

@end
