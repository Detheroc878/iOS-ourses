//
//  Accessors.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "Accessors.h"

@implementation Accessors

@synthesize myName = _myName;

#pragma mark - Accessors
- (NSString *)myName
{
    if ([_myName isEqualToString:@"KOLJA"]) {
        return @"Vasja";
    }
    return _myName;
}

- (void)setMyName:(NSString *)myName
{
    _myName = myName;
    NSLog(@"My name changed %@", myName);
}

@end
