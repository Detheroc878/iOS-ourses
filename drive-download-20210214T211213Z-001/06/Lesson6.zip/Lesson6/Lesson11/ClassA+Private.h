//
//  ClassA+Private.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "ClassA.h"

@interface ClassA (Private)

@end
