//
//  AttributesSample.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AttributesSample : NSObject

// NOT PREFERED
@property NSString *simpleStr; // (strong, atomic, readwrite)
@property (strong) NSString *strongStr; // (strong, atomic, readwrite)
@property (weak) NSString *weakStr; // (weak, atomic, readwrite)

// PREFERED
@property (weak, nonatomic) NSString *nonatomicStr; // (weak, nonatomic, readwrite)
@property (weak, atomic) NSString *atomicStr; // (weak, atomic, readwrite)

// NOT PREFERED
@property NSInteger simpleInt; // (assign, atomic, readwrite)

// PREFERED
@property (assign, nonatomic) NSInteger nonatomicInt; //(assign, nonatomic, readwrite)
@property (assign, nonatomic, readonly) NSInteger readonlyInt; //(assign, nonatomic, readonly)

// NOT PREFERED
@property (assign, nonatomic, readwrite) NSInteger readwriteInt; //(assign, nonatomic, readwrite)


// samples
@property (strong, nonatomic) NSString *linkString;
@property (copy, nonatomic) NSString *copiedString;

@property (assign, nonatomic, readonly) NSInteger readonlyProperty;

// PREFERED
@property (weak, nonatomic, getter=getSpecialVar, setter=updateSpecialVar:) NSArray *specialVar;

- (void)updateReadonlyProperty:(NSInteger)value;

@end
