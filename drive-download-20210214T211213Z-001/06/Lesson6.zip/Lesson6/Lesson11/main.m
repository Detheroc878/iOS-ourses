//
//  main.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Holder.h"
#import "AttributesSample.h"
#import "Accessors.h"

#import "Accessors+Dynamic.h"


int main(int argc, const char * argv[]) {
    @autoreleasepool {

        // strong, weak
        Holder *holder = [Holder new];
        holder.obj1 = [ClassA new]; // holder will hold this value
        holder.obj2 = [ClassB new]; // holder will hold this value
        
        NSLog(@"1");
        
        holder.obj1.obj = holder.obj2; 
        holder.obj2.obj = holder.obj1;
        
        NSLog(@"2");

        holder.obj2 = nil;
        
        NSLog(@"3");

        //
        ClassA *strongValueObj = [ClassA new];
        [strongValueObj createValue];
        [strongValueObj printValue];
        
        ClassB *weakValueObj = [ClassB new];
        [weakValueObj createValue];
        [weakValueObj printValue];
        //
        
        // Attributes
        // copy
        NSMutableString *test = [NSMutableString new];
        NSLog(@"%p", test);

        AttributesSample *obj3 = [AttributesSample new];
        obj3.linkString = test;
        NSLog(@"%p", obj3.linkString);

        obj3.copiedString = test;
        NSLog(@"%p", obj3.copiedString);

        [test appendFormat:@"hello"];
        NSLog(@"");
        
        // readonly
        NSLog(@"%li", obj3.readonlyProperty);
//        obj3.readonlyProperty = 2; // readonly - cant set value for readObly property

        [obj3 updateReadonlyProperty:2];
        NSLog(@"%li", obj3.readonlyProperty);


        
        // Accessors
        Accessors *obj4 = [Accessors new];
        [obj4 setMyName:@"name"];
        obj4.myName = @"newName";
        
        NSString *str = obj4.myName;
        NSLog(@"%@", str);

        [obj4 setDynamicStr:@"dynamicStr value"]; //crash if no setter/getter provided
    }
    
    return 0;
}
