//
//  ClassA.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "ClassA.h"

@implementation ClassA

- (void)createValue
{
    NSObject *value = [NSObject new];
    // value is local object in this method
    // if nothing keeps it, it will be deleted after method will end
    _value = value;
}

- (void)printValue
{
    NSLog(@"%@", self.value);
}

@end
