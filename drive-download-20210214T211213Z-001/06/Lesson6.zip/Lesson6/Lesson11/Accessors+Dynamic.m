//
//  Accessors+Dynamic.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "Accessors+Dynamic.h"

@implementation Accessors (Dynamic)

@dynamic dynamicStr; // ifg you put dynamic it tell compil. that set and get will be provided somewhere in runtime - warning dissapear, but it will crash if not provide it (unrecognized selector). To remove crash uncomment get/set below

//- (void)setDynamicStr:(NSString *)dynamicStr
//{
//    
//    self.myName = [self.myName stringByAppendingString:dynamicStr];
//}
//
//- (NSString *)dynamicStr
//{
//    return self.myName;
//}

@end
