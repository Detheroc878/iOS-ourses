//
//  Holder.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ClassA.h"
#import "ClassB.h"

@interface Holder : NSObject

@property (strong, nonatomic) ClassA *obj1;
@property (strong, nonatomic) ClassB *obj2;

@end
