//
//  AttributesSample.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "AttributesSample.h"

@interface AttributesSample ()

@property (assign, nonatomic, readwrite) NSInteger readonlyProperty;

@end

@implementation AttributesSample

- (void)updateReadonlyProperty:(NSInteger)value
{
    _readonlyProperty = value; // prefered in init, setter, getter.
    // you can also use _propertyName if you want to evade setter or getter
    self.readonlyProperty = value; // only if redeclarate it as readwrite in .m file
}

@end
