//
//  ClassA+Private.m
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import "ClassA+Private.h"

@implementation ClassA (Private)

@end
