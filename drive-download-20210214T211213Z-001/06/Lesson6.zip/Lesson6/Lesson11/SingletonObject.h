//
//  SingletonObject.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingletonObject : NSObject

// should be at the top
+ (instancetype)sharedInstance;

// properties
@property (assign, nonatomic) NSInteger intVar;

// methods
- (void)setupDefaults;
- (void)configureWithName:(NSString *)aName;

@end
