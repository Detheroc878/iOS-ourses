//
//  ClassA.h
//  Lesson11
//
//  Created Kyryl Horbushko on 2/2/18.
//  Copyright © 2016 Sigma. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ClassB;

@interface ClassA : NSObject

@property (weak, nonatomic) ClassB *obj; // will not increase retain count of obj

@property (strong, nonatomic, readonly) NSObject *value;

- (void)createValue;
- (void)printValue;

@end
