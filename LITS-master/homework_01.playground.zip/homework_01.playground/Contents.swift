//: Playground - noun: a place where people can play

import UIKit

class Note {
    
    static var dateFormatter : DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy.mm.dd HH:MM"
        
        return formatter
    }()
    
    let date: Date
    let text: String
    let tags: [String]
    
    var sortedTags: [String] {
        return self.tags.sorted()
    }
    
    var shortTagsOnly: [String] {
        return self.tags.filter {
            $0.characters.count < 5
        }
    }
    
    var tagsInfo: String {
        let result: String = self.tags.reduce("") {
            $0 + "[\($1)] "
        }
        
        return result
    }
    
    var uppercasedTags: [String] {
        return self.tags.map {
            $0.uppercased()
        }
    }
    
    var name: String {
        didSet {
            print("Name changed for \(self) from \(oldValue) to \(self.name)")
        }
    }
    
    init?(date: Date = Date(), name: String = "", text: String = "", tags: [String] = []) {
        
        if date.compare(Date()) == .orderedDescending {
            return nil
        }
        
        self.date = date
        self.name = name
        self.text = text
        self.tags = tags
    }
    
    func description() -> String {
        let dateInfo = Note.dateFormatter.string(from: self.date)
        
        var tagsInfo = ""
        
        for tag in self.tags {
            tagsInfo += "[\(tag)] "
        }
        
        let result = "\(dateInfo)\n\(name)\n\(text)\n\(tagsInfo)\n"
        
        return result
    }
}

guard let note = Note(date: Date()) else {
    return
}

