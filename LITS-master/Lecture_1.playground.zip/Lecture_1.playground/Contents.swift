//: Playground - noun: a place where people can play

import Foundation

struct Point {
    var x: Int
    var y: Int
    
    mutating func offset(by x: Int, _ y: Int) {
        self.x += x
        self.y += y
    }
}

var point = Point(x: 0, y: 0)
point.offset(by: 5, 10)

class Record {
    var name: String = ""
    var lastName: String = ""
    
    func fullName() -> String {
        return self.name + " " + self.lastName
    }
}

let record = Record()
let fullName = record.fullName()



class Person {
    
    let name: String
    let lastName: String
    
    required init(name: String, lastName: String) {
        self.name = name
        self.lastName = lastName
    }
    
    convenience init(lastName: String) {
        self.init(name: "", lastName: lastName)
    }
}

class UkrainianBoy: Person {
    
    let middleName: String
    
    required init(name: String, lastName: String) {
        super.init(name: name, lastName: lastName)
        self.middleName = ""
    }
    
    init(name: String, lastName: String, middleName: String) {
        
        if name == "" || lastName == "" || middleName == "" {
            return nil
        }
        
        super.init(name: name, lastName: lastName)
        
        self.middleName = middleName
    }
}














































